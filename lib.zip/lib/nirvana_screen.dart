import 'package:flutter/material.dart';

class NirvanaScreen extends StatefulWidget {
  const NirvanaScreen({Key? key}) : super(key: key);

  @override
  State<NirvanaScreen> createState() => _NirvanaScreenState();
}

class _NirvanaScreenState extends State<NirvanaScreen> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(


    );
  }
}
