import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:glistener/screens/home/Album.dart';
import 'package:glistener/screens/home/popmixscreen.dart';
import 'package:glistener/screens/library/library.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../common/styles/const.dart';
import '../../modal/Home_Model.dart';
import 'package:http/http.dart'as http;

import 'Artist.dart';
import 'Genre.dart';
import 'Mood.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final List<String> imgList = ['1','2','3','4' ];

  ConnectivityResult _connectionStatus = ConnectivityResult.none;
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<ConnectivityResult>? _connectivitySubscription;

  String?   image_file,user_id = "";
  var status,message,tokanget,data,song_name,artist_genre_id,artist_artist_id,artist_album_id,artist_modd_id;



   List<Genre> genredata=[];
   List<Artist> artistdata=[];
   List<Albums> albumsdata=[];
   List<Yourmood> yourmooddata=[];

  @override
  void initState() {
    super.initState();

    setState(() {

      homepageapi();
    });
  }
  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    setState(() {

    });
    super.dispose();
  }

  Future<void> initConnectivity() async {
    late ConnectivityResult result;
    try {
      result = await _connectivity.checkConnectivity();
    } on PlatformException catch (e) {
      return;
    }

    if (!mounted) {
      return Future.value(null);
    }

    return _updateConnectionStatus(result);
  }
  Future<void> _updateConnectionStatus(ConnectivityResult result) async {
    setState(() {
      _connectionStatus = result;
    });
  }


  showLoaderDialog(BuildContext context) {
    AlertDialog alert = AlertDialog(
      content:  Row(
        children: [
          CircularProgressIndicator(),
          Container(
              margin: EdgeInsets.only(left: 7), child: Text("Loading...")),
        ],
      ),
    );
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }


  Future<Home_Model> homepageapi() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    user_id=prefs.getString('user_id');
    tokanget=prefs.getString('login_user_token');

    var response = await http.post(Uri.parse(BASE_URL+homePageapi),headers: {'Authorization': 'Bearer $tokanget',}, body: toMap());
    showLoaderDialog(context);

    data=response.body;

    print(Home_Model.fromJson(json.decode(response.body)).status);
    print(Home_Model.fromJson(json.decode(response.body)).success);
    print(Home_Model.fromJson(json.decode(response.body)).message);

    status = (Home_Model.fromJson(json.decode(response.body)).status);
    message = (Home_Model.fromJson(json.decode(response.body)).message);

    setState((){

      genredata=Home_Model.fromJson(json.decode(response.body)).genre!;
      artistdata=Home_Model.fromJson(json.decode(response.body)).artist!;
      albumsdata=Home_Model.fromJson(json.decode(response.body)).albums!;
      yourmooddata=Home_Model.fromJson(json.decode(response.body)).yourmood!;
      // song_name = Home_Model.fromJson(json.decode(response.body)).genre[0].genreType;
      // image = Home_Model.fromJson(json.decode(response.body)).genre[0].image;

    });
    Navigator.pop(context);


    if(status==200){


    }else{
      Navigator.pop(context);

      Fluttertoast.showToast(
          msg: message,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor:Colors.black,
          textColor: Colors.white,
          fontSize: 16.0);
    }
    return Home_Model.fromJson(json.decode(response.body));
  }
  Map toMap() {
    var map =  Map<String, dynamic>();

    map["user_id"] = user_id.toString();

    return map;
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colorappblack,
      body: Container(
        padding: EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(

            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Continue mixing',style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
                  fontWeight: FontWeight.w700,fontSize: 16,height: 2)),
              sizedboxheight(10.0),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10)
                ),
                height: deviceheight(context,0.22),
                width: deviceWidth(context),
                child: CarouselSlider(
                  options: CarouselOptions(
                    autoPlay: true,
                    aspectRatio: 2.0,
                    enlargeCenterPage: true,
                  ),
                  items: imgList.map((item) => Container(
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                      color: Colors.accents[Random().nextInt(Colors.accents.length)].withOpacity(0.8),
                    ),
                    padding: EdgeInsets.all(10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: deviceWidth(context,0.5),
                              child: Text('Friends Forever- My Mix',style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w700,fontSize: 14,height: 1.5),
                              maxLines: 1,
                              ),
                            ),
                          SvgPicture.asset('assets/icons/Vector.svg')
                          ],
                        ),
                        Text('Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
                            ,style: TextStyle(color: colorWhite  ,fontFamily: 'Mulish',
                            fontWeight: FontWeight.w400,fontSize: 10),
                        maxLines: 3,),
                       sizedboxheight(5.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width: deviceWidth(context,0.5),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SvgPicture.asset('assets/icons/timer.svg'),
                                  sizedboxwidth(8.0),
                                  Text('1:35 minutes',style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w700,fontSize: 14,height: 2),maxLines: 1,),
                                ],
                              ),
                            ),
                            Container(
                              width: deviceWidth(context,0.1),
                              height: deviceheight(context,0.05),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: colorWhite,
                              ),
                              child: SvgPicture.asset('assets/icons/cearcl back.svg',
                                fit: BoxFit.none,
                                width: 40,height: 40,
                                color: Colors.accents[Random().nextInt(Colors.accents.length)].withOpacity(0.5),
                             ),
                            )
                          ],
                        ),
                      ],
                    ),
        ),
      ))
        .toList(),
                ),
              ),

              sizedboxheight(10.0),
              hedingrow('Genre'),
              sizedboxheight(10.0),
              genrelist(),
              sizedboxheight(10.0),
              hedingrow('Artists For You'),
              sizedboxheight(10.0),
              artisteforyoulist(),
              sizedboxheight(10.0),
              hedingrow('Top Albums'),
              sizedboxheight(10.0),
              topalbumslist(),
              sizedboxheight(10.0),
              hedingrow('Your Mood'),
              sizedboxheight(10.0),
              moddlist(),
              sizedboxheight(100.0),
            ],
          ),
        ),
      ),
    );
  }
  Widget hedingrow(titel){
    return   Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(titel,style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
            fontWeight: FontWeight.w700,fontSize: 16,height: 2)),
        InkWell(
          onTap: () {

            if(titel == "Genre"){
              Get.to(() => GenreScreen(type: 1));

            }else
              if(titel == "Artists For You"){
                Get.to(() => ArtistScreen());


            }else if (titel == "Top Albums"){
                Get.to(() => AlbumScreen());

              }else if (titel == "Your Mood"){
                Get.to(() => MoodScreen());

              }
            print("objecttttttt");

          },
          child: Text('See All',style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
              fontWeight: FontWeight.w500,fontSize: 16,height: 2)),
        ),
      ],
    );
  }
  Widget genrelist(){
    return  Container(
      height: 130,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: genredata.length,
          itemBuilder: (BuildContext context , int index){
            return InkWell(
              onTap: (){
                artist_genre_id=genredata[index].id.toString();

                print("artist_genre_id");
                print(artist_genre_id);
                print("artist_genre_id");

                Get.to(() => PopMixScreen(type:'1',genre_id:artist_genre_id,name:genredata[index].genreType));
              },
              child: Container(
                width: 120,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Container(
                        height: 100,width: 100,
                        decoration: BoxDecoration(

                          image:  DecorationImage(
                            fit: BoxFit.fill,
                              // image: AssetImage('assets/icons/image.png',)
                              image: NetworkImage("${BASE_URL_img_home}genre/"+genredata[index].image! )
                          ),
                        ),
                        child:Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                            height: 95,
                              child: Padding(
                                padding:  EdgeInsets.only(left: 5,right: 5),
                                child: Center(
                                  child: Text('${genredata[index].genreType}'
                                    ,style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w600,fontSize: 12,height: 1.5),
                                    textAlign: TextAlign.center,
                                    maxLines: 2,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              height: 5,
                              color: Colors.accents[Random().nextInt(Colors.accents.length)],
                            )
                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            );
          }),
    );
  }

  Widget artisteforyoulist(){
    return  Container(
      height: 150,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: artistdata.length,
          itemBuilder: (BuildContext context , int index){
            return Column(
              children: [
                InkWell(
                  onTap: (){
                    artist_artist_id=artistdata[index].id.toString();
                    print("artist_artist_id");
                    print(artist_artist_id);
                    print("artist_artist_id");

                    Get.to(() => PopMixScreen(type:'2',artist_id: artistdata[index].id.toString(),name:artistdata[index].artistName));
                  },
                  child: Container(
                    margin: EdgeInsets.only(right: 10,bottom: 10),
                    height: 100,width: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      image:  DecorationImage(
                          fit: BoxFit.fill,

                          image: NetworkImage("${BASE_URL_img_home}artist/"+artistdata[index].image!)

            ),
                    ),
                  ),
                ),
                InkWell(
                  onTap: (){
                    artist_artist_id=artistdata[index].id.toString();
                    print("artist_artist_id");
                    print(artist_artist_id);
                    print("artist_artist_id");

                    Get.to(() => PopMixScreen(type:'2',artist_id: artistdata[index].id.toString(),name:artistdata[index].artistName));                  },
                  child: Text('${artistdata[index].artistName}',style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,fontSize: 12)),
                ),
              ],
            );
          }),
    );
  }

  Widget topalbumslist(){
    return  Container(
      height: 130,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: albumsdata.length,
          itemBuilder: (BuildContext context , int index){
            return InkWell(
              onTap: () {
                artist_album_id=albumsdata[index].id.toString();

                print("artist_album_id");
                print(artist_album_id);
                print("artist_album_id");

                Get.to(() => PopMixScreen(type:'3',album_id:artist_album_id,name:albumsdata[index].albumType));              },
              child: Container(
                width: 120,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Stack(
                    children: [
                      Container(
                        height: 100,width: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          image:  DecorationImage(
                              fit: BoxFit.fill,

                              // image: AssetImage('assets/icons/image.png',)
                              image: NetworkImage('${BASE_URL_img_home}albums/${albumsdata[index].image!}')
                          ),
                        ),

                      ),
                      Container(
                        height: 100,width: 100,
                       color: colorblack.withOpacity(0.3),
                        child:Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Center(
                            child: Text('${albumsdata[index].albumType}'
                              ,style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w600,fontSize: 12,height: 1.5),
                              textAlign: TextAlign.center,
                              maxLines: 2,
                            ),
                          ),
                        ),
                      )

                    ],
                  ),
                ),
              ),
            );
          }),
    );
  }
  Widget moddlist(){
    return  Container(
      height: 130,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: yourmooddata.length,
          itemBuilder: (BuildContext context , int index){
            return InkWell(
              onTap: () {

                artist_modd_id=yourmooddata[index].id.toString();

                print("artist_modd_id");
                print(artist_modd_id);
                print("artist_modd_id");

                Get.to(() => PopMixScreen(type:'4',artist_modd_id:artist_modd_id,name:yourmooddata[index].moodType));


              },
              child: Container(
                width: 120,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Stack(
                    children: [
                      Container(
                        height: 100,width: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          image:  DecorationImage(
                              fit: BoxFit.fill,

                              // image: AssetImage('assets/icons/image.png',)
                              image: NetworkImage('${BASE_URL_img_home}mood/${yourmooddata[index].image!}')
                          ),
                        ),

                      ),
                      Container(
                        height: 100,width: 100,
                        color: colorblack.withOpacity(0.3),
                        child:Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Center(
                            child: Text('${yourmooddata[index].moodType}'
                              ,style: TextStyle(color: colorWhite  ,fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w600,fontSize: 12,height: 1.5),
                              textAlign: TextAlign.center,
                              maxLines: 2,
                            ),
                          ),
                        ),
                      )

                    ],
                  ),
                ),
              ),
            );
          }),
    );
  }

}
