import 'package:flutter/material.dart';

class Recorderdemo extends StatefulWidget {
  const Recorderdemo({Key? key}) : super(key: key);

  @override
  State<Recorderdemo> createState() => _RecorderdemoState();
}

class _RecorderdemoState extends State<Recorderdemo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
